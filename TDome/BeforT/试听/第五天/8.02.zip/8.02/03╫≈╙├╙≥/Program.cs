﻿namespace _03作用域
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //作用域
            // 所谓的作用域 就是看大括号的范围

            //int x = 10;
            ////int x = 20;


            //int y = 20;

            //if (true)
            //{
            //     x = 10;
            //    y = 20;
            //}
            //else
            //{
            //     x = 20;

            //}

            
            if (true)
            {
                if (true)
                {

                    int a = 10;
                   
                    if (true)
                    {
                         a = 30;
                        int b = 50;
                        if (true)
                        {
                             a = 20;
                        }


                    }
                }


            }














        }
    }
}
