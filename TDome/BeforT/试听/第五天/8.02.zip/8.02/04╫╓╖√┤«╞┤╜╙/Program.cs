﻿namespace _04字符串拼接
{
    internal class Program
    {
        static void Main(string[] args)
        {
            ////什么是字符串？    ""
            //string str = "我是一个字符串";
            //string str2 = "我是另外一个一个字符串";
            //// - * /       + 加号在某些情况下 有其他含义  可以进行字符串拼接

            //string str3 = "小笨蛋" + str2 + str;
            //Console.WriteLine(str3);


            ////当 int 遇上 string 拼接的时候，会直接拼接为字符串
            //int x = 10;
            //int y = 20;

            //string a = "一号";
            //string b = "二号";

            //// x + y + a + b;   ?  30一号二号
            //string aa =  x + y + a + b;
            //Console.WriteLine(x + y + a + b);
            //// a + b + x + y    ?   一号二号1020
            //Console.WriteLine(a + b + x + y);

            //// x + a + y + b    ?
            ///


            string name = "张三";
            int age = 12;
            string like1 = "李四";
            string like2 = "王五";
            string like3 = "老六";

            Console.WriteLine("我叫" + name+ "，我今年" + age + "岁" + "我平常最喜欢的事，就是和" + like1 + like2 + like3 + "一起打麻将");
         

            string aa = $"我叫{name},我今年{age}岁，我平常最喜欢的事，就是和{like1},{like2}，{like3}一起打麻将";
            Console.WriteLine(aa);
    *        
   ***
  *****
 *******
*********
 *******
  *****
   ***
    *



        }
    }
}
