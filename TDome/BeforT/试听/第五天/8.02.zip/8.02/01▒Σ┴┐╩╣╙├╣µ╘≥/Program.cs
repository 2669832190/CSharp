﻿namespace _01变量使用规则
{
    internal class Program
    {
        static void Main(string[] args)
        {

          

            int x =1;

            Console.WriteLine(x);


            //变量的使用  先声明 再使用



        }
    }
}
