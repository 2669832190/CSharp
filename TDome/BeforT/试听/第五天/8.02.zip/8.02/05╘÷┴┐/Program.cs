﻿namespace _05增量
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //自增量
            // + - * /   +=  -=  *=  /*     ++  --
            //int a = 10 ; 
            //int b = 20;
            ////a += b;   a = a + b;
            //a = a + b;
            //Console.WriteLine(a);

            //a += 1;
            //Console.WriteLine(a);

            int a = 10;
            //int b = a++; //a++;
            //int b = ++a;        //++a;

            //Console.WriteLine($"我是a{a}");
            //Console.WriteLine($"我是b{b}");
            //共同点：每次执行完毕之后 自身都会 +1
            //不同点：当++在后，直接赋值 自身再+1        当++在前，自身先加+1  再赋值


            //int c = ++a + a++ + a++ + ++a;
            //a给c的值   11   11     12    14
            //a的变化   11    12     13    14

            //Console.WriteLine(c);

            int c = a--  +  a++  +  --a  +  ++a  +  --a  +  a++ +  ++a;
        //a给c的值  10       9       9       10      9       9       11
        //a的变化   9        10      9       10      9       10      11



            Console.WriteLine(c);





        }
    }
}
