﻿
namespace _07循环复习
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int num = 1;
            int count = 0; //记录循环多少次
            while (num<100000) 
            {
                //Console.WriteLine("我能循环几次");
                //num += 2;
                num = num + 2;
                count++;
               
            }
            Console.WriteLine(count);
            //Console.WriteLine(num);
            // 1. 初始值
            // 2. 循环区间
            // 3. 增量


            //while (true)
            //{


            //}




        }
    }
}
