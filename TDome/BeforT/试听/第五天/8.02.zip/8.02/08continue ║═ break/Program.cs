﻿namespace _08continue_和_break
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int x = 0;
            while (x < 4)
            {
                //Console.WriteLine($"我什么时候不执行，{x}");
                x++;

                if (x == 2)
                {
                    //break;   //终止循环 
                    Console.WriteLine($"我是if里面的{x}");
                    continue;   //跳出本次循环，继续下一次循环
                }
                Console.WriteLine($"我什么时候不执行，{x}");
                Console.WriteLine("laskpodjahsoiuhfgisu");
            }



        }
    }
}
