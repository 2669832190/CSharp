﻿namespace _06开关思想
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //int a = 10;
            //bool flag = false;
            //if (a > 5)
            //{
            //    if (a == 10)
            //    {
            //         flag = true;
            //    }




            //    if (flag)
            //    {
            //        Console.WriteLine("我想执行这里的代码");
            //    }
            //}


            int x = 1;
            bool flag = false;
            while (x <= 10) 
            {
                if (x % 3 == 0)
                {
                    flag = true;
                }
                x++;
            }

            if (flag)
            {
                Console.WriteLine("我是if让我出来");
            }
            else
            {
                Console.WriteLine("我是else让我出来");
            }







        }
    }
}
