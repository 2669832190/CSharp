﻿namespace _10for
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //int num = 0;
            //while (num <10)
            //{
            //    num++;
            //}
            //Console.WriteLine(num);

            //int x = 2;
            //int y = 2;
            //for (; x < 100;)
            //{
            //    if (x % y == 0 && x > y)
            //    {
            //        //只要进入到这里 则证明不是素数
            //        x++;
            //        y = 2;
            //        continue;
            //    }
            //    else
            //    {
            //        y++;
            //    }

            //    if (x == y || x == 2)
            //    {
            //        //这里的if 表示 素数
            //        Console.WriteLine(x);
            //        x++;
            //        y = 2;
            //    }
            //}

            //for (int i = 0; i < 20;)
            //{
            //    break;
            //    Console.WriteLine("死循环");
            //}

            int count = 0;
            for (int i = 0; i < 10; i++)
            {
                for (int j = 0; j < 10; j++)
                {
                    count++;
                    Console.WriteLine($"我是{i},我是{j}");
                }
            }
            Console.WriteLine(count);


        }
    }
}
