﻿namespace _02变量名的命名规则
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int x32165165;
            int Int;


            /*
                首字符 必须是大小写字母  ，_  
                特殊字符 ！#$~....不能用
                关键字  保留字
                严格的区分大小写
                驼峰命名 ：大驼峰 UserName   User        小驼峰  userNameName     user
                同一个作用域 不得有相同的变量    
                命名的时候，尽可能的清晰表达 该变量的作用   见名知意
                   
                


            */
            int a;
            int A;

            //int a;

            string userName;
            int count;







        }
    }
}
