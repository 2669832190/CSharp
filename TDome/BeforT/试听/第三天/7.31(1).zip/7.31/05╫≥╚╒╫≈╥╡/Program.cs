﻿namespace _05昨日作业
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //提示用户输入账号 密码 （admin 123456） 都输对了 直接提示你想提示的   ；
            //    输错了 提示 账号错了 还是密码错了  
            //    错的话 三次机会; 用完还不对 提示你想提示的

            Console.WriteLine("请您输入账号");
            string userName = Console.ReadLine();  // bendan
            Console.WriteLine("请您输入密码");
            string password = Console.ReadLine();

            if (userName == "admin" && password =="123456")
            {
                Console.WriteLine("登录成功");
            }
            else
            {
                if (userName != "admin")
                {
                    Console.WriteLine("账号输入错误");
                }
                else if (password != "123456")
                {
                    Console.WriteLine("密码输入错误");
                }
                else
                {
                    Console.WriteLine("账号密码全错");
                }


                //Console.WriteLine("请您输入账号");
                //string userName2 = Console.ReadLine();  // bendanerhao
                //Console.WriteLine("请您输入密码");
                //string password2 = Console.ReadLine();
                Console.WriteLine("请您输入账号");
                userName = Console.ReadLine();  // bendanerhao
                Console.WriteLine("请您输入密码");
                password = Console.ReadLine();
                if (userName == "admin" && password == "123456")
                {
                    Console.WriteLine("登录成功");
                }
                else
                {
                    if (userName != "admin")
                    {
                        Console.WriteLine("账号输入错误");
                    }
                    else if (password != "123456")
                    {
                        Console.WriteLine("密码输入错误");
                    }
                    else
                    {
                        Console.WriteLine("账号密码全错");
                    }


                    Console.WriteLine("请您输入账号");
                    userName = Console.ReadLine();  // bendanerhao
                    Console.WriteLine("请您输入密码");
                    password = Console.ReadLine();

                    if (userName == "admin" && password == "123456")
                    {
                        Console.WriteLine("登录成功");
                    }
                    else
                    {
                        if (userName != "admin")
                        {
                            Console.WriteLine("账号输入错误");
                        }
                        else if (password != "123456")
                        {
                            Console.WriteLine("密码输入错误");
                        }
                        else
                        {
                            Console.WriteLine("账号密码全错");
                        }
                    }

                        Console.WriteLine("三次机会已经用完，笨蛋");

                }



                //int num = 10;
                //Console.WriteLine(num);
                //num = 20;
                //Console.WriteLine(num);

                //num = 30;
                //Console.WriteLine(num);


            }





        }
    }
}
