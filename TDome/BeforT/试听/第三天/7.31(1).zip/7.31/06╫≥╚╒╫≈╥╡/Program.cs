﻿namespace _06昨日作业
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //用户输入 4个数字 找到 最大的和 最小的(if  else if  else)     a b c d

            int a = 56;
            int b = 5654;
            int c = 564;
            int d = 545;   //  a -> b c d     b -> a c d

            if (a>b && c >d)  // b>a && c >d     a>b && d>c   //  a>c && b>d    c>a && b>d   a>c && d>b  // a>d && b>c    d>a && b>c   a>d && c>d
            {
                if (a > c)  //四个数字 两两比较，会有两个大值 和 两个小值
                {
                    Console.WriteLine("a最大");
                }
                else
                {
                    Console.WriteLine("c最大");
                }

                if (b > d)
                {
                    Console.WriteLine("d最小");
                }
                else
                {
                    Console.WriteLine("b最小");
                }
            }else if (b > a && c > d)
            {
                if (b>c)
                {
                    Console.WriteLine("b最大");
                }
                else
                {
                    Console.WriteLine("c最大");
                }

                if (a > d)
                {
                    Console.WriteLine("d最小");
                }
                else
                {
                    Console.WriteLine("a最小");
                }

            }






        }
    }
}
