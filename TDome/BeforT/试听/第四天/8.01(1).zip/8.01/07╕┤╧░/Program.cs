﻿namespace _07复习
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // 数学运算符， 比较运算符


            // 数学运算符 + - * /    % 取余   
            //----------------------------------------
            //int a = 11; 
            //int b = 5;
            //double c =  a / b;  // 2

            //double a = 11;
            //double b = 5;
            //double c = a / b;
            //Console.WriteLine(a / b); // 2.2
            //Console.WriteLine(c);

            //double d = 3;
            //Console.WriteLine(d);

            //int a = 22;
            //int b = 25;
            //int c =  a % b;
            //Console.WriteLine(c);

            // 比较运算符   >  <    >=   <=    &与    |或     !非      &&逻辑与  ||逻辑或   == 判断
            //--------------------------------------
            // bool 也叫 布尔类型   他只有两个值，   true  false
            //bool flag =  1 < 2;
            //Console.WriteLine(flag);
            //bool flag2 = 1 > 2;
            //Console.WriteLine(flag2);

            //bool falg = 1 > 2   &     2 < 1; // 同真 则为真  否则为假
            //Console.WriteLine(falg);

            //bool falg = 1 > 2 | 2 > 1;      // 同假 则为假  否则为真
            //Console.WriteLine(falg);

            //bool falg = false;
            //Console.WriteLine(!falg);
            //Console.WriteLine(!true);


            //bool falg = 1 > 2 && 2 > 1; // 同真 则为真  否则为假
            //Console.WriteLine(falg);    //  当 && 的左侧为假时，则右侧不会执行

            //bool falg = 1 < 2 || 2 > 1;      // 同假 则为假  否则为真
            //Console.WriteLine(falg);   // 当 || 的左侧为真时，则右侧不需要执行


            // == 在编程中 ==表示 两侧是否相等， 带有判断之意
            //Console.WriteLine(2 == 2);
            //Console.WriteLine("abc" == "abc");



        }
    }
}
