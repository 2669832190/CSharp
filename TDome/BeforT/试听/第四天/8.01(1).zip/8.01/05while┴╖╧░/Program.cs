﻿
namespace _05while练习
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //计算 1- 100之间的和  
            //当x为 66的时候，停止计算 并跳出循环

            int x = 0; //这个x 是增量
            int total = 0;  //这是0-100的总和
            while (x <=100)
            {

                //我们发现， x可以当作 0-100之间的所有数字
                total = total + x;
                x = x + 1;
              
                if (x == 66)
                {
                    //break; // 跳出循环
                    continue;  // ？
                    
                }
   
            }
            Console.WriteLine(x); //最后一次循环结束之后，x为 101 ,会再次对 x <= 100 进行判断，结果为false，所以停止循环
            Console.WriteLine(total);

            //0 + 1 +2 +3 + 4 .... + 100 需要一个对x累加的过程

        }
    }
}
