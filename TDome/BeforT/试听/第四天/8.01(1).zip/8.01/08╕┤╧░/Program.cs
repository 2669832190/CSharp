﻿namespace _08复习
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //if else
            //if (判断表达式)   格式
            //{

            //}
            //else
            //{

            //}

            int num = 10;
            //if (num>3)
            //{
            //    Console.WriteLine("如果小括号里面是true,则我会出现");
            //}

            ////Console.WriteLine("abc"); if else 是一个整体，中间不允许有其他的代码

            //else
            //{
            //    Console.WriteLine("如果小括号里面是false,则我会出现");
            //}


            //if (1>3)
            //{
            //    Console.WriteLine("执行这里");
            //}
            //else if (3 >5)
            //{
            //    Console.WriteLine("执行这里");
            //}
            //else
            //{
            //    Console.WriteLine("执行这里");

            //}


            //用户输入 3个数字 
            //找到 最大的和 最小的(if  else if  else)   

            Console.WriteLine("请您输入第一个数字");
            string str1 =  Console.ReadLine();//能够获取用户在控制台输入的东西
                                              //Console.WriteLine("我是输出语句里面的 str" + str);
            Console.WriteLine("请您输入第二个数字");
            string str2 = Console.ReadLine();
            Console.WriteLine("请您输入第三个数字");
            string str3 = Console.ReadLine();
            int num1 = int.Parse(str1);  //通过 Parse方法 将字符串变成 数字   "123"    "abc"
            int num2 = int.Parse(str2);
            int num3 = int.Parse(str3);
            Console.WriteLine(num1);
            Console.WriteLine(num2);
            Console.WriteLine(num3);

            if (num1 > num2)
            {
                // if  else 只能执行一个   
                // 若代码执行此处 则证明  num1 大于 num2
                if (num2 > num3)
                {
                    //如果执行此处的if 则证明 num3 最小
                    Console.WriteLine($"{num3}最小");
                    Console.WriteLine($"{num1}最大");
                }
                else
                {
                    //如果执行此处的else 则证明 不仅  num1 大于 num2   且 num3 也大于 num2
                    Console.WriteLine($"{num2}最小");
                    if (num1 > num3)
                    {
                        Console.WriteLine($"{num3}最小");
                    }
                    else
                    {
                        Console.WriteLine($"{num1}最小");
                    }

                }


            }
            else
            {
                // 若代码执行此处 则证明  num2 大于 num1
                if (num1 > num3)
                {
                    //如果执行此处的if 则证明 num3 最小
                    Console.WriteLine($"{num3}最小");
                    Console.WriteLine($"{num2}最大");
                }
                else
                {
                    //如果执行此处的else 则证明 不仅  num2 大于 num1   且 num3 也大于 num1
                    Console.WriteLine($"{num1}最小");
                    if (num2 > num3)
                    {
                        Console.WriteLine($"{num2}最大");
                    }
                    else
                    {
                        Console.WriteLine($"{num3}最大");
                    }

                }

            }



        }
    }
}
