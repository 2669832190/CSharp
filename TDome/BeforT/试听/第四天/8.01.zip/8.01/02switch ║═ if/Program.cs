﻿namespace _02switch_和_if
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // if 不仅可以处理 值与值的对比，还能处理 区间判断
            // switch 更擅长处理 值与值 ：区间是不太行了

            //int x = 10;
            //if (x == 100)
            //{

            //}
            //else
            //{

            //}

            //int x = 100;
            //if (x > 10)
            //{

            //}

            //int x = 100; 这样不行
            //switch (x )
            //{
            //    case x > 10:
            //        Console.WriteLine();


            //}


//用户输入 成绩  ；返回用户的 评分
//>= 90  A
//>= 80  B
//>= 70  C
//>= 60  D
//< 60   E

        }
    }
}
