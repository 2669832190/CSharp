﻿namespace _01初始C_
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //-----------------------------------------
            //变量
            //声明变量 格式：   类型 + 名称(自定义)
            //int a; // 声明了一个int类型的变量，名字叫做a     1.
            //// 变量 可以理解为  会变化的量
            //a = 10;  //将10这个值，赋值给了等号左侧的a        2.
            //         // 等号是 做了 赋值的行为 把右边的值  赋值 给了左侧的变量
            //Console.WriteLine(a);

            //a = 30; //将变量a 重新赋值 为 30

            //Console.WriteLine(a);


            //-------------------------------------------------------
            //类型  数据类型
            //int num;
            //num = 10;
            //int num = 10;//声明了一个int类型的变量，名字叫做num，且将10赋值给了num
            //int num2 = 10.3;//错误的演示:不能将小数 给到 整数类型的变量num2


            // 基本数据类型
            //int      整数类型          1    2    3
            //double   浮点类型  小数    2.1    2.2
            //bool     布尔类型  判断    true  false    布尔类型 只有两个值
            //char     字符类型          'a'     '.'
            //string   字符串类型        "ab"
            //int a = 1;
            //double b = 2.2;
            //bool c  = true;
            //char d = '.';
            //string e = ".........";



            //-----------------------------------------------------
            //数学运算符  + - * /   %取余
            //int a = 3;
            //int b = 20;
            //int c = a* b;
            //Console.WriteLine(c);
            //int c = b % a;// 2  所谓的取余  也就是获取余数


            //---------------------------------------------
            //比较运算符 >    <   >=   <=
            //Console.WriteLine( 1 > 2);
            //Console.WriteLine( 2 >= 2);
            //int a = 10;
            //double b = 10.2;
            //bool c = a > b;
            //Console.WriteLine(c);


            //------------------------------------
            //进阶版比较   &与  |或   ！非     &&逻辑与   ||逻辑或    !=不等    ==  
            //Console.WriteLine(    1 < 2  &   1 < 3    ); //同真则为真
            //Console.WriteLine(    1 < 2  |   1 > 3    ); //同假则为假
            //Console.WriteLine(!true);
            //bool a = true;
            //Console.WriteLine(!a);

            //Console.WriteLine(1 > 2 && 1 < 3); //同真则为真
            //Console.WriteLine(1 < 2 || 1 > 3); //同假则为假
            // & | 和  && || 的共同点：结论都一样的，
            //                 不同点：所谓的逻辑是有一定含义的，
            //                         当左侧执行结束 结果已经注定，则右侧不再执行

            //Console.WriteLine( "a" != "a"  );
            //Console.WriteLine("a" == "a" );

            //------------------------------------------------------------------
            //隐式转化 强制转化   整数类型
            //byte表示8位无符号整数，它的取值范围是0~255；
            //short表示16位有符号整数，它的取值范围是 - 32768~+32767；
            //int表示 32位有符号整形，它的取值范围是 - 2147483648~+2147483647；
            //long表示64位有符号整形，它的取值范围 是-9223372036854775805~+9223372036854775807；
            //
            //   double   -1.79E+308到 + 1.79E+308
            //隐式转化

            //byte a = 255;
            //short b = a;
            //强制转化
            //short a = 32767;
            //byte b = (byte)a;
            //Console.WriteLine(b);
            //int a = 32771;
            //short b = (short)a;
            //Console.WriteLine(b);

            //double x = 2.3;
            //int y = (int)x;

            //-------------------------------------------------------------------------
            //判断语句
            //if (1>3)
            //{
            //    Console.WriteLine("我看了true");
            //}
            //else
            //{
            //    Console.WriteLine("我看到了false");
            //}


            //if (true)
            //{

            //}
            //else if(1>3)
            //{

            //}
            //else if (true)
            //{

            //}
            //else
            //{

            //}


            //while 循环

            //while (true)
            //{
            //    Console.WriteLine("我是while"); //死循环
            //}


            //while循环 三步：
            //1.初始量
            //2.循环区间
            //3.增量

            //int a = 1;
            //while (a < 10)
            //{

            //    a = a + 1;
            //}
            //Console.WriteLine(a);

            //计算 1-100之间所有的偶数之和   包含100

            int x = 1;
            int total = 0;
            while (x <= 100)
            {
                if ( x % 2 == 0)
                {
                    //只要来到这里的 就都是偶数
                    //如何将 偶数加起来
                    total = total + x;
                }
                x = x + 1;

            }
            Console.WriteLine(total);




        }
    }
}
