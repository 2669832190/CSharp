﻿namespace _06转化练习
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //int num = 10 / 3; //数学运算符的存在，会存在隐式转化
            //Console.WriteLine(num);

            //double num2 = 10 / 2;

            ////int num3 = 3.3;  这样就不可以了，
            ///


            double x = 10 / 3;

            double y = (double)10 / 3;

            double z = 10 * 1.0 / 3;
            Console.WriteLine(z);
            Console.WriteLine(10 * 1.0);
            double zz = 10 * 1.0;
            Console.WriteLine(zz);

            //doble    -100.0  + 100.0    65.0



        }
    }
}
