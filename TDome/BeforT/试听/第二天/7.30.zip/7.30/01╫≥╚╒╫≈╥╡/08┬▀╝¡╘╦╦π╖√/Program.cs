﻿namespace _08逻辑运算符
{
    internal class Program
    {
        static void Main(string[] args)
        {
           
            /*
                |  或
                &
                ！
            */



            Console.WriteLine(1 < 2 | 2 < 3);//或    ”|“ 两侧有一个为真 则结果为真， 两个为假，则结果为假
            Console.WriteLine(1 < 2 & 2 > 3);//与    ”&“ 两侧都为真，则结果为真，若有一假 则结果为假
            Console.WriteLine(!true);          // 取反 非    ”!“   将结果取反



            /*
                ||     逻辑或
                &&     逻辑与
            */

            Console.WriteLine(1 < 2 || false);  //当 || 左边为真时，会返回 true   右边将不再执行，
            Console.WriteLine(1 < 2 && false);  //当 $$ 左边为假时，会返回 false  右边将不再执行



        }
    }
}
