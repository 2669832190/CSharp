﻿namespace _02昨日作业
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //3.控制台 任意输入一个3位数 返回 个位 十位 百位

            Console.WriteLine("请输入一个三位数");
            string input = Console.ReadLine(); // 获取用户输入的文本
            Console.WriteLine("我想看看input是个啥" + input);  // "123"
            int num = int.Parse(input); // 因为input是一个字符串，字符串不能进行数学运算，
            //int.Parse() 这个方法，会将字符串变成数字  "123"        "./,asd"
            Console.WriteLine("我想看看num是个啥" + num);  // 123

            //123 % 10;
            //Console.WriteLine(123 % 10);

            int gewei = num % 10;  //% 叫做余   余数是多少，这个值就是多少， 123 / 10     12....3
            int shiwei = num % 100 /10; // 1 ..... 23    2.3
            int baiwei = num / 100;
            Console.WriteLine($"百位数字是{baiwei},十位数字是{shiwei},各位数字是{gewei}");

        }
    }
}
