﻿namespace _04昨日作业
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // 1.控制台 任意输入一个数值 几天 返回 几周 零 几天 例 ： 8  一周零一天

            Console.WriteLine("请输入一个合理的天数");
            string str = Console.ReadLine();
            int day = int.Parse(str);

            int week = day / 7;
            int days = day % 7;
            Console.WriteLine($"{week}周{days}天");
        }
    }
}
