﻿namespace _03昨日作业
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //控制台 任意输入一个秒数 返回 几天 几个小时 几分钟   36000

            //假设 输入的是 7845618912   

            Console.WriteLine("请输入一个合适的秒数"); //搞一个提示 告诉用户该做什么
            string str = Console.ReadLine();//获取用户输入的字符
            int num = int.Parse(str);

            int day = num / (24*60*60);
            int hour = num / (60 * 60);
            int minute = num /  60;
            Console.WriteLine($"多少天{day}，多少小时{hour},多少分{minute}"); //模板字符串

        }
    }
}
