﻿namespace _05隐式类型转化_强制转化
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //double num = 123;
            //int x = 10;
            //double y = x;  //隐式转化

            //double x1 = 10.5;
            //int y1 = (int)x1; //强制转化

            //byte表示8位无符号整数，它的取值范围是0~255；
            //short表示16位有符号整数，它的取值范围是 - 32768~+32767；
            //int表示 32位有符号整形，它的取值范围是 - 2147483648~+2147483647；
            //long表示64位有符号整形，它的取值范围 是-9223372036854775805~+9223372036854775807；



            byte num1 = 250;
            //short num2 = num1;

            //short num3 = 25000;
            //byte num4 = num3;


            //int num1 = 1125;
            //long num2 = num1;

            long num3 = 9223372036854775807;
            int num4 =(int)num3;
            //看取值范围， 小的给大的，隐式转化，  大的给小的 强制转化






            //变量 ：变化的量
            //int a = "1";       //int 数据类型(强调变量a接收什么类型的值)   a 变量名称(自定义)   = 赋值 将右边的值 赋值给左边  
            //a = 20;


            //上网浏览 小数是如何进行 隐式 和 强制转化

            //整数的默认类型 为 int
            //小数的默认类型 为 double

            //小数 被称为  浮点型 double float
            //float f = 20.3F;
            //float l = 100.3f;   //float类型需要在值类型之后 加 F，才能进行赋值
            //Console.WriteLine(l);

            //double a = 20.3;
            //float b = (float)a;
            // double的取值范围 大于 float的取值范围



            int a = 10;
            long c = 20;
            double b= a;
            double d = c;

            long aa = 10;
            float f = aa;


            


            // byte -> short -> int -> long -> float -> double  
            //从左至右  取值范围 逐渐增大
        }
    }
}
