﻿namespace _01昨日作业
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //int x = 10;
            //int y = 30;
            //交换变量 不依赖 第三个变量

            //int x; //声明一个int 类型的变量，变量名字叫做x   写法：类型 + 名字
            //x = 10; //将 10 这个值， 赋值给 变量x

         
            int x = 10;  //声明一个int 类型的变量，变量名字叫做x ,且给变量x 赋了一个初始值
            int y = 30;

            //x = y - x; // y-x表示 30 -10 即结果为20，   值
            //y = y - x;
            //x = x + y;

            y = y - x;
            x = x + y;
            y = x - y;


            Console.WriteLine(x);
            Console.WriteLine(y);


        }
    }
}
