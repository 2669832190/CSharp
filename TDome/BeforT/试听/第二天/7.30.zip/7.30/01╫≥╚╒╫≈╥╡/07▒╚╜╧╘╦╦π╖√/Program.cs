﻿namespace _07比较运算符
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //  > <   >= <=   !=不等
            Console.WriteLine( 1 > 2 ); // false
            Console.WriteLine( 3 > 2 ); // true  

            bool a  = true; // 布尔类型  只有两个值，  false  true

            int aa = 20;
            int bb = 20;
            Console.WriteLine(aa != bb);

            bool cc  = aa != bb;


        }
    }
}
