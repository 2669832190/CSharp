﻿namespace _09判断
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //判断语句
            //if (1<2)
            //{
            //    Console.WriteLine("我是if");
            //}
            //else
            //{
            //    Console.WriteLine("我是else");
            //}


            if (1 > 2)
            {
                Console.WriteLine("我是if");
            }
            else if (3 < 2)
            {
                Console.WriteLine("我是else 后面的 if");
            }
            else
            {
                Console.WriteLine("我是else后面的 else");
            }










        }
    }
}
