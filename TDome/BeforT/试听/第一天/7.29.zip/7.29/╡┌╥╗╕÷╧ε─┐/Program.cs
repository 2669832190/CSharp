﻿
// 双斜线  单行注释    就是注释 作用：对某一行代码进行注解，解释，
// 他不会被编译器编译，



//namespace 声明 命名空间

namespace 第一个项目
{
    //internal 访问控制修饰符   public 公共的



    //class 声明类的  关键字
    // 类是什么东西，？
    // 类 是一种数据结构，可以封装 数据 方法 和 其他的类

    //Program 类名
    // 切记，这里的Program 不要理会

    // class Aa   名字随便起 首字母大写，使用大驼峰命名法
    //什么是大驼峰命名        小驼峰
    //NameSpace  Number       nameSpace   number
    //所有自定义的名字 要完成一个 见名知意 的 意思


    //static 访问修饰符
    //void 代表当前方法(函数) 没有返回值
    //string[] args 函数的参数(形参)  -> 对应着实参
    // Main() main方法
    // 如果一个单词后面跟了一个小括号 就可以称为 方法(函数)
    // 它是当前程序的 主入口   所有的代码都将在这里执行
    //          简单讲：如果你的代码，想被执行，就需要写到 main方法中




    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("23lkahsiudh"); //这是一个输出语句

            //快捷语法 CW  在小括号中 添加  双引号，  双引号中的所有东西 都会在控制台中 打印出来
            Console.WriteLine("我想在控制台输出,一句话5641891jhguyi");
            //为什么非要使用双引号呢，
            // 因为 Console.WriteLine()  输出结果是一个字符串
            // 双引号引起来的 所有东西 被叫做字符串
            // 字符 +  双引号 叫字符串
            //为什么叫 字符串， 是由多个字符连接起来的，

        }
    }
}
