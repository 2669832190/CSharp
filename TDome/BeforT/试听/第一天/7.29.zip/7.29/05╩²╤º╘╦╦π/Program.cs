﻿namespace _05数学运算
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //int num = 10; //为什么叫变量， 变化的量
            //Console.WriteLine(num);
            //num = 30;
            //Console.WriteLine(num);

            // + - * / 

            //int num1 = 10;
            //int num2 = 20;
            //Console.WriteLine(num1+num2);

            //int num3 =  num1 + num2;
            //Console.WriteLine(num3);


            //int num4 = num1 - num2;
            //Console.WriteLine(num4);


            // +=  -=  *=  /=
            //int num1 = 10;
            //int num2 = 20;

            ////int num3 = num1 + num2;
            ////Console.WriteLine(num3);


            //Console.WriteLine(num1);
            ////num1 += num2;
            //num1 = num1 + num2;


            //Console.WriteLine(num1);

            int num1 = 10;
            int num2 = 20;

            //num1 *= num2;
            //  num1 = num1 * num2
            num2 *= num1;
            Console.WriteLine(num1);
            Console.WriteLine(num2);





        }
    }
}
