﻿namespace _03快捷键
{
    internal class Program
    {
        static void Main(string[] args)
        {
            /*
            ctrl +  s  保存
            ctrl + k + d  格式化文档   会把没有对其的代码 弄整齐
            ctrl + k + c  单行注释
            ctrl + k + u  取消注释
            ctrl + z 撤回
            ctrl + y 前进
            shift + 左右  逐个选中
            shift + home  选中到 行首
            shift + end   选中到 行尾
             */

            Console.WriteLine("sl;ojaiops");





        }
    }
}
