﻿namespace _02注释
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello, World!");
            // 单行注释    注释，解释当前代码什么意思

            /*
             * 多行注释
             * 
             * 
             * 
             * 
             */
            //Console.WriteLine("Hello, World!");   ctrl + k + c


           /* Console.WriteLine("Hello, World!");
            Console.WriteLine("Hello, World!");    ctrl + shift + /
            Console.WriteLine("Hello, World!");
            Console.WriteLine("Hello, World!");
            Console.WriteLine("Hello, World!");*/    


        }
    }
}
