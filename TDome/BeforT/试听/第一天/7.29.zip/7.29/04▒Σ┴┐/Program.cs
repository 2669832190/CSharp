﻿namespace _04变量
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int num = 4;
            Console.WriteLine(num);


            // number
            int num2;    // 声明了一个int 类型 的 变量 ，名字叫做 num2 
                        // 如果声明一个变量 ？    数据类型 + 名称     int aa
            num2 = 4;   // 将一个数字4 ， 赋值 给了 一个 num2 变量，
                        // 在编程语言中， 一个= 表示 赋值的行为， 也就是 把右边的值  给到左边


            // int 中文直译 整型 整数的意思 
            // 可以理解为声明变量 mun3 , int 强调 num3这个变量 只能接收 整数 的值
            int num3 = 1234598;
            Console.WriteLine(num3);
            Console.WriteLine("num3");

            string str;     //声明了一个string 类型 的 变量 ，名字叫做 str
            str = "123456"; //双引号 引起来的所有东西，都被称为 字符串




        }
    }
}
