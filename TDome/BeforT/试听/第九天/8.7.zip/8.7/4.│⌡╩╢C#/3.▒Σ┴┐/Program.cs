﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _3.变量
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //变量：
            //变量就是对程序中某个数据的引用，比如x表示一个身份证号码

            //变量在程序中只是一个存储数据的名字，每一个变量都会有一个指定的数据类型，类型决定了所占用内存空间的大小


            //变量的声明（定义）
            //格式：  数据类型+变量的名字
            //常用的数据类型：int(整数类型)、double(浮点型)、bool(布尔类型)、string(字符串)

            //见名知意
            int age;
            double height;
            string name;

            //变量命名规范
            //1.只能包含字母、数字、_、@（注意：数字不能做开头、@只能当开头）
            int a;
            int a1;
            int a_1;
            //int 1a;
            //int a@;
            int @b;
            //2.不能用内置的类库和关键字
            //int Console;
            //Console.WriteLine();
            //int int;
            //int class;
            //3.不能重复声明一个变量
            int c;
            //int c;
            //4.大小写敏感
            int D;
            int d;

            //变量的赋值
            //   =  赋值运算符    把=右边的值  赋值给 左边的变量
            int i1;
            i1 = 10;
            //如果变量再次被赋值，他就会将原来的值丢弃掉，重新保存新的值
            i1 = 20;
            Console.WriteLine(i1);


            //声明变量的同时，直接赋值
            int i2 = 10;
            Console.WriteLine(i2);
            Console.WriteLine("i2");

            string name1, name2, name3;
            int i3 = 10, i4 = 20, i5 = 30;


            //变量先声明，再赋值，再使用
            //Console.WriteLine(S1);
            int S1;
            //Console.WriteLine(S1);
            S1 = 10;
            Console.WriteLine(S1);


            string name4 = "坤坤";
            int age1 = 18;
            string time = "两年半";
            Console.WriteLine("他的名字是"+name4+"人家今年"+age1+"岁~"+"练习时长"+time);
        }
    }
}
