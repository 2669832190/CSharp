﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _1.Console类
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Conosle  c#中已经封装好的类
            Console.WriteLine("Hello World!");

            //方法：
            //输出到控制台
            //输出后会换行
            Console.WriteLine("Hello World!");

            //输出后不会自动换行
            Console.Write("张三");
            Console.Write("李四");
            Console.WriteLine("Hello World!");

            //从控制台输入
            //获取输入的一行文本，返回一个字符串（输入之后需要按下回车键才算完成）
            Console.ReadLine();
            Console.WriteLine("用户输入了一行字符串，并且按下了回车键");


            string name = Console.ReadLine();
            Console.WriteLine("我的的名字是"+name);

            //获取用户按下的一个键
            Console.ReadKey();
            Console.WriteLine("用户按下了一个键");

            //清除控制台上的内容
            Console.Clear();

            //上面的这些操作，后边都带有一个小括号，我们将这些叫做方法的调用。


            //属性
            Console.WriteLine("获取控制台的背景颜色");
            //获取属性
            Console.WriteLine(Console.BackgroundColor);
            //设置属性
            Console.BackgroundColor = ConsoleColor.Green;
            Console.WriteLine("修改过的新的控制台的背景颜色"+Console.BackgroundColor);
            Console.BackgroundColor = ConsoleColor.Black;
        }
    }
}
