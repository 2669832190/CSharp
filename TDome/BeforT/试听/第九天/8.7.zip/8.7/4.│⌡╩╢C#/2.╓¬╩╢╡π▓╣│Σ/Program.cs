﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2.知识点补充
{
    internal class Program
    {
        //Main   整个程序的主入口   你写的代码想执行就必须写到这里边   
        static void Main(string[] args)
        {
            //注释：
            //单行注释      //
            //多行注释      /*      */        ctrl+shift+?
            /*Console.WriteLine("1111111111");
            Console.WriteLine("1111111111");
            Console.WriteLine("1111111111");
            Console.WriteLine("1111111111");
            Console.WriteLine("1111111111");
            Console.WriteLine("1111111111");*/

            //   #region
            //   #endregion  


            #region 代码块1
            Console.WriteLine("1111111111");
            Console.WriteLine("1111111111");
            Console.WriteLine("1111111111");
            Console.WriteLine("1111111111");
            Console.WriteLine("1111111111");
            Console.WriteLine("1111111111");
            Console.WriteLine("1111111111");
            Console.WriteLine("1111111111");
            Console.WriteLine("1111111111");
            Console.WriteLine("1111111111");
            Console.WriteLine("1111111111");
            Console.WriteLine("1111111111");
            Console.WriteLine("1111111111");
            Console.WriteLine("1111111111");
            Console.WriteLine("1111111111");
            #endregion



            //快捷键：
            //ctrl+x 剪切
            //ctrl+z 撤回
            //ctrl+y 恢复
            //ctrl+s 保存
            //ctrl+k+d   格式化文档
            //ctrl+d 向下复制一行

        }
    }
}
