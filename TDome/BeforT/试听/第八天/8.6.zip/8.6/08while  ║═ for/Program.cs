﻿namespace _08while__和_for
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // while
            // while循环 需要三个条件 
            //1.初始量
            //2.循环区间
            //3.增量


            //int x = 1;
            //while (x < 10)
            //{
            //    Console.WriteLine("我是循环");
            //    if (x == 3)
            //    {
            //        Console.WriteLine("我看到了3");
            //    }

            //    x = x + 1;
            //}
            //Console.WriteLine(x);
            //Console.WriteLine("我什么时候执行");



            // 计算 1-100（包含100）之间所有的整数和

            //1.初始量
            //2.循环区间
            //3.增量


            //int x = 1; //x是1-100之间的每一个数字
            //int total = 0;  //表示所有的数字的总和
            //while (x <= 100 )
            //{
            //    //Console.WriteLine(x);//此时发现 x 就是每一个数字 
            //    // total = x; //这样写，是给total循环一次 赋值一次             // 得出结论，只能通过累加 
            //    total = total+ x;
            //    x = x + 1;
            //}
            //Console.WriteLine(total);



            //----------------------------------

            //int i = 1;
            //int total = 0;
            //for (; i <= 100; )   // i++执行一次 给自己加1
            //{
            //    total = total + i;

            //    i = i + 1;
            //}

            //Console.WriteLine(total);

            //int total = 0;
            //for (int i = 1; i <= 100; i++)
            //{
            //    total = total + i;
            //}
            //Console.WriteLine(total);


            //需要一个东西，来记录循环的次数
            
            for (int i = 0; i < 10; i++)//外层
            {
                int count = 0;
                for (int j = 0; j < 10; j++)//内层
                {
                    count = count + 1;
                    Console.WriteLine($"我是{i}，我是{j}");
                }
                Console.WriteLine(count);
            }
          



        }
    }
}
