﻿namespace _01初识变量
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Console：控制台   Write：写 写入     Line：直线 一行   ("这里的东西会被输出到控制台") 前提是需要用双引号引起来
            //Console.WriteLine("我想在控制台输出一句话，能够让我看到，");
            //Console.WriteLine("Hello, World!");
            //Console.WriteLine("首次见面");
            //Console.WriteLine();  cw是快捷方式

            //-----------------------------------------------
            //绿色的字体是什么？  叫做注释 ：解释当前代码表示什么意思，或者干了什么事
            //  单行注释,
            //  代码执行时，不会被编译器 编译

            /*  Console.WriteLine("我是多行注释");
              Console.WriteLine("我是多行注释");
              Console.WriteLine("我是多行注释");
              Console.WriteLine("我是多行注释");
              Console.WriteLine("我是多行注释");
              Console.WriteLine("我是多行注释");
              Console.WriteLine("我是多行注释");
              Console.WriteLine("我是多行注释");
              Console.WriteLine("我是多行注释");
              Console.WriteLine("我是多行注释");*/
            // 👆  上面是多行注释  快捷方式：ctrl + shift + ?      或者手动多行注释 ：   /*  */



            //--------------------------------------------------------------------------------
            //变量  字面意思理解：就是可以变化的量(值)
            //int a;   //声明了一个 int(整数)类型的变量，名字叫做a
            //a = 10;  //将10这个值，赋值给了变量a，
                     //  = 在这里的作用是什么？   赋值的作用， 
                     // = 在编程语言中，等号是将  右侧的值 赋值给 左侧的变量
                     // int 的作用是什么？   强调变量a 只能接收 int(整数)类型的值，
                     // a 的作用是什么？ 只是一个变量名，可以理解为一个容器，
            //Console.WriteLine(a);


            int b = 20;//声明了一个 int(整数)类型的变量，名字叫做b,且将20这个值，赋值给了变量b，
            Console.WriteLine(b);
            Console.WriteLine(b);
            //变量变量 ，一定要变




            b = 30;
            Console.WriteLine(b);
            //变量声明的格式     数据类型 +  名称  = 值


            int  aa  =  30; 



        }
    }
}
