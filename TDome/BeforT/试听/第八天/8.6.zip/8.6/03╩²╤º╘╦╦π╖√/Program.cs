﻿namespace _03数学运算符
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //  +  -  *  /  %取余
            //Console.WriteLine( 1+ 2);
            //int a = 10;
            //int b = 20;
            ////int c = a + b;
            ////Console.WriteLine(c);
            //int c = 3 % 5;
            //Console.WriteLine(c);

            // +=  -=  *=  %=
            //int a = 10;
            //int b = 20;
            //Console.WriteLine(a);//10
            ////a = a + b;
            ////a += b;
            //a %= b;
            //// a = a % b
            //b %= a;
            //b = b % a;
            //Console.WriteLine(a);// 
            //Console.WriteLine(b);
        }
    }
}
