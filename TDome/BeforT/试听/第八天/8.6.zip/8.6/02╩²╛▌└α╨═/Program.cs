﻿namespace _02数据类型
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //  int 整数      默认类型
            //  double  小数  默认类型
            //  bool   布尔类型 只有两个值， true 和 false
            //  char   字符类型   用单引号 包裹起来，   里面不管是什么，只能写一个
            //  string 字符串类型 用双引号 包裹起来，   里面不管是什么，随便写 
            // 声明变量的格式    类型 + 名称 = 值
            int a = 10;
            byte aa = 20;

            double b = 10.2;
            float bb = 10.2f;

            bool c = true;
            bool cc = false;

            char d = 'a';

            string e = "das>?/张三; 吧v         p'asp;oi";
            Console.WriteLine(e);


            // 如何声明一个字符串

            string str = "1123";


            //bool aaa =  true;
            //30;

           a = 10;

        }
    }
}
