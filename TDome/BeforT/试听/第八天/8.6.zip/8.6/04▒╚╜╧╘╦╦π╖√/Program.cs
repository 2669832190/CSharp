﻿namespace _04比较运算符
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // >  <    >=    <=   
            //Console.WriteLine(1 > 2 );
            //bool falg = 2 >= 2;
            //Console.WriteLine(falg);


            // &与     |或       !非  取反

            // & 两侧有一个假 则为假， 同真则为真
            //Console.WriteLine( 1>3   &  2<3  );
            //Console.WriteLine(1 < 3 & 2 < 3);

            //// | 两侧有一个真 则为真， 同假则为假
            //Console.WriteLine(1 > 3 | 2 < 3);
            //Console.WriteLine(1 < 3 | 2 < 3);
            //Console.WriteLine(1 > 3 | 2 > 3);

            //bool aa = false;
            //Console.WriteLine(!aa);


            // &&逻辑与   ||逻辑或    !=    ==
            //&&两侧有一个假 则为假， 同真则为真
            // 当&&的左侧结果是false的时候，则右侧不再执行
            Console.WriteLine(1 < 3 && 2 > 3);
            Console.WriteLine(1 > 3 && 2 < 3);
            Console.WriteLine(1 < 3 && 2 < 3);

            // || 两侧有一个真 则为真， 同假则为假
            // 当 || 左侧的结果为 true 的时候，则右侧不再执行
            Console.WriteLine(1 > 3 || 2 < 3);
            Console.WriteLine(1 < 3 || 2 < 3);
            Console.WriteLine(1 > 3 || 2 > 3);

            // !=    ==
            // =  赋值    !=不等     == 带有判断之意
            Console.WriteLine(3 != 2);
            Console.WriteLine( 3 == 2);





        }
    }
}
