﻿namespace _06if练习
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // 有三个数字  a   b  c  但不知道具体的值，求最大值，最小值
            Console.WriteLine("请您输入第一个数字");
            string aa = Console.ReadLine();//可以获取用户在控制台输入的东西
            int a = int.Parse(aa);  //int.Parse() 将字符串转化成数字   "123"可以转化数字    "abc"不可以
            Console.WriteLine("请您输入第二个数字");
            string bb = Console.ReadLine();//可以获取用户在控制台输入的东西
            int b = int.Parse(bb);
            Console.WriteLine("请您输入第三个数字");
            string cc = Console.ReadLine();//可以获取用户在控制台输入的东西
            int c = int.Parse(cc);

            if (a > b)
            {
                //a的值 比 b大
                if (b > c)
                {
                    //a > b > c如果执行这里，证明c是最小值
                    Console.WriteLine($"{c}是最小值");
                    Console.WriteLine($"{a}是最大值");
                }
                else
                {
                    //  a>b  c >b  证明 b值最小值
                    Console.WriteLine($"{b}是最小值");
                    if (a > c)
                    {
                        Console.WriteLine($"{a}是最大值");
                    }
                    else
                    {
                        Console.WriteLine($"{c}是最大值");
                    }
                }
            }
            else
            {
                //b 的值 比 a 大
                if (a > c )
                {
                    Console.WriteLine($"{c}是最小值");
                    Console.WriteLine($"{b}是最大值");
                }
                else
                {
                    //  b > a     c > a  
                    Console.WriteLine($"{a}是最小值");
                    if (b > c)
                    {
                        Console.WriteLine($"{b}是最大值");

                    }
                    else
                    {
                        Console.WriteLine($"{c}是最大值");
                    }
                }
            }





        }
    }
}
