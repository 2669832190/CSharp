﻿namespace _05if
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //// 判断语句
            //if (1 > 3) //执行if  还是 else  根据()中的判断表达式来决定
            //{
            //    Console.WriteLine("我是if中的语句");
            //}
            //else if (3 > 4)
            //{
            //    Console.WriteLine("我是else中的语句");
            //}
            //else 
            //{
            //    Console.WriteLine("我是第二个也是最后一个else");
            //}



            //int a = 1 > 3 ? 1 : 2;
            //int b = 1 > 3 ? 1 :  3>4  ?   3:2;


            if (1>3)
            {
                if (false)
                {
                    Console.WriteLine("我是if中的if");
                }
                else
                {
                    Console.WriteLine("我是if中的else");
                }
            }
            else
            {
                if (false)
                {
                    Console.WriteLine("我是else中的if");




                }
                else
                {
                    Console.WriteLine("我是else中的else");
                }
            }





        }
    }
}
