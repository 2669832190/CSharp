﻿namespace _07强制_隐式转化
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // 10   10.1
            //int x = 10;
            //double xx = x;  //通过下面的错误信息，得出 当前的写法 是隐式转化
            //double xxx = 20;



            //double y = 20.2;
            //int yy = y;  //强制转化


            //下面四个都是 整数类型
            //byte表示8位无符号整数，它的取值范围是0~255；
            //short表示16位有符号整数，它的取值范围是 - 32768~+32767；
            //int表示 32位有符号整形，它的取值范围是 - 2147483648~+2147483647；
            //long表示64位有符号整形，它的取值范围 是-9223372036854775805~+9223372036854775807；
            //byte a = 255;
            //short b = a;

            //short a = 32767;
            //byte b = (byte)a;

            //1 1.1

            //double a = 10.1;
            //long b = (long)a;

            //double > float >  long > int > short > byte  由大到小










        }
    }
}
