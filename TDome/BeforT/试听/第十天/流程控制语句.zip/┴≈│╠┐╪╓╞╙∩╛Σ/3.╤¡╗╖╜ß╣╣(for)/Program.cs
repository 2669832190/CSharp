﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _3.循环结构_for_
{
    internal class Program
    {
        static void Main(string[] args)
        {

            //循环就是帮助我们执行一些重复的相同的相似的代码，会按照我们预定的重复顺序去执行循环体中的代码

            //需求：在控制台输出5次”唱跳Rap篮球"
            Console.WriteLine("唱跳Rap篮球");
            Console.WriteLine("唱跳Rap篮球");
            Console.WriteLine("唱跳Rap篮球");
            Console.WriteLine("唱跳Rap篮球");
            Console.WriteLine("唱跳Rap篮球");


            //         初始条件              判断条件       迭代变量
            /*for (声明一个循环控制变量; 循环执行的条件; 更新循环变量)
            {
                循环体（需要重复执行的代码块）
            }*/

            //int i = 0;     声明一个i，用于记录循环执行的次数（只有第一次循环的时候执行）
            //i<5;           循环继续执行的条件，条件成立了，循环继续执行；条件不成立，终止执行
            //{}             循环体（需要重复执行的代码块）
            //i++            执行一次循环体，就会进行一次计数，然后回到判断条件

            //i的值会从0开始递增到5，为5时条件不成立，循环结束

            for (int i = 0; i < 5; i++)
            {
                Console.WriteLine("唱跳Rap篮球！");
                Console.WriteLine(i);
            }

            //注意点：
            //初始条件可以写到for上边，但是第一个;不能省略
            //迭代变量可以写到循环语句的最后，但是第二个;不能省略

            int i1 = 0;
            for (; i1 < 5;)
            {
                Console.WriteLine("唱跳Rap篮球！");
                Console.WriteLine($"进入循环时{i1}");
                i1++;
                Console.WriteLine($"离开循环时{i1}");
            }
            Console.WriteLine(i1);   //循环结束时，i1的值



            //循环注意：
            //要素要合适
            /*for(int i = 0; i<-1; i++)
            {
                Console.WriteLine(i);    //i永远大于-1，一次都不执行
            }*/
            //一定保证循环是有尽头的（没有尽头称为死循环）
            /*for (int i =0; i <5;)
            {
                Console.WriteLine(i);   //没有迭代变量造成死循环
            }*/
            /*for(int i =0;i<10;i--)
            {
                Console.WriteLine(i);   //迭代变量使用不当造成死循环
            }*/
            /*for(int i =0;i == i; i++)
            {
                Console.WriteLine(i);   //判断条件使用不当造成死循环
            }*/


            for (int i = 20; i > 9; i--)
            {
                Console.WriteLine(i);
            }
            for (int i = 0; i < 5; i++)
            {
                Console.WriteLine(i);
            }

            for (int i = 0; i < 10; i += 2)
            {
                Console.WriteLine(i);
            }


            //课堂练习：
            //控制台打印1 - 100之间的整数
            for (int i = 0; i < 100; i++)
            {
                Console.WriteLine(i + 1);

            }
            for (int i = 1; i < 101; i++)
            {
                Console.WriteLine(i);

            }
            //打印10到1
            for (int i = 10; i > 0; i--)
            {
                Console.WriteLine(i);
            }
            //打印1 - 100之间的偶数
            for (int i = 0; i < 101; i++)
            {
                if (i % 2 == 0)
                {
                    Console.WriteLine(i);
                }
            }
            //求1 -100所有数字的和
            int sum = 0;
            for (int i = 0; i < 101; i++)
            {
                sum += i;     //sum = sum + i;
            }
            Console.WriteLine(sum);
            //求1 - 100之间所有的偶数的和
            int sum1 = 0;
            for (int i = 0; i < 101; i++)
            {
                if (i % 2 == 0)
                {
                    sum1 += i;
                }
            }
            Console.WriteLine(sum1);


        }
    }
}
