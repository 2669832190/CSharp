﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2.选择结构_switch_
{
    internal class Program
    {
        static void Main(string[] args)
        {

            //switch  适用于等值条件的判断   用来变量和多个有限的值一一匹配
            //不同点：
            //if结构适用于某个变量处于某个连续区间，进行的范围的判断
            //switch结构判断数值是否相同，不能进行范围的判断

            /*switch (变量)
            {
                case 1:   //判断变量的值和1是否相同
                    //这里满足之后执行的代码
                    xxxxxx;
                    break;  //表示中断，满足了就不再往后对比了
                case 2:
                    xxxxxxx;
                    break;
                case 3:
                    xxxxxx;
                    break;
                default:
                    xxxxxx;
                    break;
            }*/


            //输出周几
            Console.Write("请输入0-6之间的数字：");
            int num = int.Parse(Console.ReadLine());

            switch(num)
            {
                case 0:
                    Console.WriteLine("周日");
                    break;
                case 1:
                    Console.WriteLine("周一");
                    break;
                case 2:
                    Console.WriteLine("周二");
                    break;
                case 3:
                    Console.WriteLine("周三");
                    break;
                case 4:
                    Console.WriteLine("周四");
                    break;
                case 5:
                    Console.WriteLine("周五");
                    break;
                case 6:
                    Console.WriteLine("周六");
                    break;
                default:   //和else相似   上述条件都不满足   则进入default
                    Console.WriteLine("输入的数字不合法！");
                    break;
            }


            string day = Console.ReadLine();
            switch(day)
            {
                case "Monday":
                    Console.WriteLine("Start of workweek");
                    break;
                case "Friday":
                    Console.WriteLine("End of workweek");
                    break;
                default:
                    Console.WriteLine("Midweek");
                    break;
            }


            //输入月份，打印季节

            //如果一个月份用一个case，太臃肿
            //可以多个case共用

            int mouth = int.Parse(Console.ReadLine());
            switch (mouth)
            {
                case 3:
                case 4:
                case 5:
                    Console.WriteLine("春季");
                    break;
            }


            //注意：
            //break不能省略
            //case后面的值可以无序，但不能重复
            //多个case可以共用一段代码
            //default可要可不要
            //case后面跟的具体的数据，要和switch()内变量的数据类型一致
        }
    }
}
