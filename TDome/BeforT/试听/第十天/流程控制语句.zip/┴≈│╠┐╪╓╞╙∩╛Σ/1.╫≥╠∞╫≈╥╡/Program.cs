﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _1.昨天作业
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //c#流程控制是编程中非常重要的一部分，它决定了代码的的执行顺序
            //C#主要分为三种基本结构：顺序结构、选择结构（分支）和循环结构

            //顺序结构是程序中最基本最简单的结构
            //在这种结构中，代码按照从上到下的顺序依次执行。
            //这是程序的默认执行方式，无需任何控制语句

            //选择结构允许程序根据一定的条件选择性地执行不同的代码块
            //C#常用的选择结构  if语句、if-else语句、if-else if ...-else语句、switch-case语句和三目运算符


            //单分支
            /*if (布尔值 / 条件表达式)
            { 
                布尔值为true时执行的代码
            }*/
            if (false)
            {
                Console.WriteLine("代码是否执行？");
            }

            //虽然条件中需要一个布尔值，但是我们一般不会直接写一个布尔值，而是通过关系运算符计算得到布尔值

            //判断一个用户是否成年
            int age = 20;
            if (age >= 18)
            {
                Console.WriteLine("成年了");
            }

            int age2 = int.Parse(Console.ReadLine());
            if (age2 < 18)
            {
                Console.WriteLine("请在成年人陪同下观看");
            }
            if (age2 >= 18)
            {
                Console.WriteLine("请节制观看");
            }


            //双分支
            /*if (布尔值/条件表达式)
            {
                条件成立时执行的代码
            }
            else
            {
                条件不成立时执行的代码
            }*/

            //上面的写法就等价于
            if (age2 < 18)
            {
                Console.WriteLine("你是未成年");
            }
            else  //否则
            {
                Console.WriteLine("你成年了");
            }


            //多分支
            /*if (布尔值/条件表达式)
            {
                
            }
            else if (布尔值/条件表达式)
            {
                
            }
            else if (布尔值/条件表达式)
            {
                
            }
            else
            {
                
            }*/

            //执行过程：当某个条件语句成立时，执行对应的代码块，都不成立，则执行else后的代码
            //注意：
            //1.判断条件是有递进关系
            //2.一旦一个分支执行了，其他分支都不执行
            //3.没有其他的情况，else可以省略


            int age3 = int.Parse(Console.ReadLine());
            if (age3 < 12)
            {
                Console.WriteLine("小学生");
            }
            else if (age3 < 15)   //12-15
            {
                Console.WriteLine("初中生");
            }
            else if (age3 < 18)  //15-18
            {
                Console.WriteLine("高中生");
            }
            else if (age3 < 22) //18-22
            {
                Console.WriteLine("大学生");
            }
            else   // >=22
            {
                Console.WriteLine("社畜");
            }

            //与多个if的区别？
            //多个if是所有的if都进行判断，条件成立都会执行
            if (age3 < 12)
            {
                Console.WriteLine("小学生");
            }
            if (age3 < 15)
            {
                Console.WriteLine("初中生");
            }
            if (age3 < 18)
            {
                Console.WriteLine("高中生");
            }
            if (age3 < 22)
            {
                Console.WriteLine("大学生");
            }
            if (age3 >= 22)
            {
                Console.WriteLine("社畜");
            }

            //除非每一个条件的范围   补充完整
            if (age3 < 12)
            {
                Console.WriteLine("小学生");
            }
            //比较运算符不能连用    15>age3>12  错误
            if (age3 >= 12 && age3 < 15)
            {
                Console.WriteLine("初中生");
            }
            if (age3 >= 15 && age3 < 18)
            {
                Console.WriteLine("高中生");
            }
            if (age3 >= 18 && age3 < 22)
            {
                Console.WriteLine("大学生");
            }
            if (age3 >= 22)
            {
                Console.WriteLine("社畜");
            }


            //分支嵌套
            int age4 = int.Parse(Console.ReadLine());
            if (age4 > 0 && age4 < 123)
            {
                if (age3 < 12)
                {
                    Console.WriteLine("儿童");
                }
                else if (age3 < 18)
                {
                    Console.WriteLine("青少你");
                }
                else if (age3 < 30)
                {
                    Console.WriteLine("青年");
                }
                else if (age3 < 50)
                {
                    Console.WriteLine("中年");
                }
                else
                {
                    Console.WriteLine("老年");
                }
            }
            else
            {
                Console.WriteLine("输入的年龄不合法");
            }


        }
    }
}
