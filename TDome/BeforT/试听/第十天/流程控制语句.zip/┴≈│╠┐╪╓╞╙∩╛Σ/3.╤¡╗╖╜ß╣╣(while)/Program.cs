﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _3.循环结构_while_
{
    internal class Program
    {
        static void Main(string[] args)
        {

            /*while (条件)
            {
                循环体，将会在条件成立时被重复执行
            }*/

            //最简单的死循环
            /*while(true)
            {
                Console.WriteLine("循环内容");
            }*/

            int i = 0;
            while (i < 5)
            {
                Console.WriteLine(i);
                i++;
            }

            //1.目标是搬砖500个，第一次搬一个，后面因为越来越熟练，每次递增一倍，1、2、4、8、16.....,搬完需要多少次？
            int count = 0;   //搬了几次
            int sum = 0;   //总数
            int num = 1;   //当前一次搬多少个
            while(sum<=500)
            {
                count++;
                //开始搬砖（总个数+当前搬得个数）
                sum = sum + num;
                //熟练度增加
                num = num * 2;
            }
            Console.WriteLine($"搬砖500个需要{count}次");


            //2.有一个学校，现在有8个人，每年学校增长23%，几年后学员可以达到100人以上？
            int year = 0;
            double people = 8;
            while(people<=100)
            {
                people = people * 1.23;
                year++;
            }
            Console.WriteLine($"{year}年之后达到100人以上，有{people}人");



            //从语法上讲，for和while可以相互转换
            //非要说区别，使用场景上
            //当你不确定循环需要执行多少次，或者说循环的执行依赖于循环体内部的逻辑，使用while更合适
            //当你需要执行一个固定次数的循环，或者在循环执行的过程中需要一个递增或递减的计数器，for循环是更好的选择




            //如果条件不满足，一次都不执行
            while(false)
            {
                Console.WriteLine("执行了吗？");
            }
            //do-while会先执行do里面的代码，执行完了再进行条件判断,不管条件满不满足，至少会执行一次
            do
            {
                Console.WriteLine("我是do-while");
            } while (false);

            //使用do-while   输出“你是坏人吗？（y/n）”  如果输入y 则输出“你真坏！”  如果输入n，则一直询问
            string res;
            do
            {
                Console.WriteLine("你是坏人吗？（y/n）");
                res = Console.ReadLine();
            } while (res != "y");
            Console.WriteLine("你真坏！");


            //while和do-while区别：
            //do-while至少执行一次，while条件不成立一次都不执行


        }
    }
}
