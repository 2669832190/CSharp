﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _6.循环嵌套
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //外层循环
            for(int i =0;i<3;i++)
            {
                Console.WriteLine("测试外层循环————");
                //内层循环    外层循环每执行1次，内层执行5次
                for(int j = 0; j < 5; j++)
                {
                    Console.WriteLine($"测试内部循环 i:{i},j:{j}");
                }
            }


            for (int i = 0; i < 2; i++)
            {
                Console.WriteLine($"i的值是{i}");
                for(int j = 0;j < 3; j++)
                {
                    Console.WriteLine($"j的值是{j}");
                    for(int k=0;k<5;k++)
                    {
                        Console.WriteLine($"k的值是{k}");
                    }
                }
            }


            //循环嵌套中使用break和continue
            for (int i = 0; i < 3; i++)
            {
                Console.WriteLine($"测试外层循环{i}");
                for (int j = 0; j < 3; j++)
                {

                    if(i==1)
                    {
                        //break和continue结束或跳出的是当前的循环，不会影响到外层循环
                        //break;
                        continue;
                    }
                    Console.WriteLine($"测试内部循环 i:{i},j:{j}");
                }
                Console.WriteLine($"外层循环结束{i}");
            }

        }
    }
}
