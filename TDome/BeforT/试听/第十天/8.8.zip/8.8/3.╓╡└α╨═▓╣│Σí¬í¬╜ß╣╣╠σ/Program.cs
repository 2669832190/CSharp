﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _3.值类型补充__结构体
{
    internal class Program
    {
        static void Main(string[] args)
        {

            //结构体可以让变量存储多个数据
            //形式上和用法上跟类基本上相同，可以理解为结构体是值类型的对象
            //2.使用
            Book book1 = new Book() { Name = "西游记", Price = 9.9};
            Book book2 = book1;
            book1.Name = "水浒传";
            book1.Price = 99.9;
            Console.WriteLine($"book1的名字是{book1.Name},book1的价格是{book1.Price}");
            Console.WriteLine($"book2的名字是{book2.Name},book2的价格是{book2.Price}");
        }
    }

    //1.定义结构体
    struct Book
    {
        public string Name;
        public double Price;
    }
}
