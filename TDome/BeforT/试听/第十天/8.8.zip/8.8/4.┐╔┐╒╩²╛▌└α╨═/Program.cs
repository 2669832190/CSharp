﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _4.可空数据类型
{
    internal class Program
    {
        static void Main(string[] args)
        {

            //引用类型
            //除了可以存储对应的数据外，还可以存储null值
            string s1 = "123";
            s1 = null;
            Console.WriteLine(s1);

            People p1 = new People();
            p1 = null;
            Console.WriteLine(p1);

            //值类型默认不能使用null赋值
            //int i1 = null;  //报错
            People p2 = new People();
            Console.WriteLine($"i:{p2.i},d:{p2.d},b:{p2.b},c:{p2.c},book:{p2.book}");
            //数值类型默认值是0
            //布尔类型默认值是false
            //字符类型默认值是/0
            //结构体默认值是空结构体

            //为了让基本数据类型可以存储null值
            //在类型后边加上一个？就表示他是一个可空的数据类型,在他原来的范围之上加一个null值，同时他的默认值就变成null了
            Console.WriteLine($"i2:{p2.i2}");

            //如果一个值是可空数据类型，后续计算会出现问题
            int? i3 = null;
            //int i4 = i3;  //报错，此时i3和i4的范围不一样了


            //用？？进行处理
            int i4 = i3 ?? 100;
            Console.WriteLine(i4);  //100
            Console.WriteLine(i3);  //null


            int? i5 = 123;
            int i6 = i5 ?? 100;
            Console.WriteLine(i6);  //123

        }
    }
    class People
    {
        public int i;
        public double d;
        public bool b;
        public char c;
        public Book book;
        public int? i2;
    }

    struct Book
    {

    }

}
