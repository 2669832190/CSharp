﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _1.数据类型2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //引用数据类型


            #region 字符串
            //string  字符串   用于存储多个字符
            //用""包裹
            //创建字符串的三种方式： ""     @""     $""

            string name = "张三";
            //转义字符     \n换行符    \t制表符  
            string test = "今天\n天真\t好！";
            Console.WriteLine(test);

            //@""    创建的字符串展示正常效果（写啥就是啥）
            string test2 = @"今天\n天真\t好！";
            Console.WriteLine(test2);
            //"   用""表示
            string test3 = @"今天\n天""真\t好！";
            Console.WriteLine(test3);


            //$""    可以插入变量
            string test4 = $"名字是：{name},天气：{test}";
            Console.WriteLine(test4);
            #endregion



            #region 对象
            //object 对象类型
            //它是所有数据类型的父类型，也就是说，可以存储任意的数据类型
            object o1 = 123;
            object o2 = "123";
            object o3 = true;
            object o4 = Sex.man;

            //我们可以定义自己的对象（自己的类），存储一系列相关的数据
            //对象的创建依赖于类
            //类：是一系列对象的描述，是一个模板                   人类
            //对象：是类的一个具体表现，我们也把它称为类的实例     张三

            //创建一个GirlFriend类型的对象，她就是GrilFriend类的实例
            GrilFriend g1 = new GrilFriend();
            //使用   对象名.成员名    的方式去操作对象
            g1.Name = "小红";
            g1.Age = 18;
            g1.clothes = "蛋黄的长裙";
            g1.hair = "蓬松的头发";
            Console.WriteLine($"我的女朋友是：{g1.Name},人家今年{g1.Age}岁~,她穿着{g1.clothes},她有{g1.hair}");
            #endregion


            //dynamic 动态类型  也可以存储任意的数据类型
            dynamic d1 = 123;
            dynamic d2 = "123";
            dynamic d3 = true;

            //dynamic 动态类型的校验发生在运行期间（类型错误也可以运行）
            Console.WriteLine(d3*100);
            //object  类型校验在编译阶段（类型错误，运行不了）
            //Console.WriteLine(o3*100);


        }

        enum Sex
        {
            man,
            woamn,
        }
    }
    //类  在namespace命名空间中使用class关键字定义一个类   
    //首字母大写
    class GrilFriend
    {
        //声明类的成员的格式：public 成员的类型 成员的名字
        public string Name;
        public int Age;
        public string clothes;
        public string hair;
    }

}
