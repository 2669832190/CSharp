﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2.数据类型的区别
{
    internal class Program
    {
        static void Main(string[] args)
        {

            //当我们把一个变量赋值给另一个变量的时候，首先就需要确认这个变量是值类型还是引用类型


            //值类型
            //保存的是值本身（存储在栈中）

            int a = 10;
            int b = a;
            a = 20;
            Console.WriteLine($"a的值是{a},b的值是{b}");
            //a作为值类型，存储在栈中，将a的值赋值给b，虽然两个变量的之相等了，但是两个变量保存在栈中的不同位置
            //所以a改变,b不会改变

            //引用类型
            //变量直接保存的是数据的内存地址（数据实体存储在堆中，栈中存储的是大小固定的内存地址）
            //当我们需要引用类型的变量时，先从栈中读取内存地址，再去通过地址找到堆中的数据值本身

            Person p1 = new Person();
            p1.Name = "张三";
            Person p2 = p1;
            p1.Name = "李四";
            Console.WriteLine($"p1的名字是{p1.Name},p2的名字是{p2.Name}");
            p2.Name = "王五";
            Console.WriteLine($"p1的名字是{p1.Name},p2的名字是{p2.Name}");

            //假如有一个引用类型的实例，他有两个成员，一个是值类型，一个是引用类型
            //他将如何存储？
            Book book1 = new Book();
            book1.Name = "西游记";
            book1.Price = 9.9;
            Book book2 = book1;
            book1.Price = 99.9;
            book2.Name = "红楼梦";
            Console.WriteLine($"book1的名字是{book1.Name},价格是{book1.Price}");
            Console.WriteLine($"book2的名字是{book2.Name},价格是{book2.Price}");
            //既然成员都是对象的一部分，那么他们都会放在堆里，遵循引用类型的分配规则


            //string  字符串
            //存储方式特殊，按照值类型去理解
            string s1 = "张三";
            string s2 = s1;
            s1 = "李四";
            Console.WriteLine($"s1是{s1},s2是{s2}");


        }
    }

    class Person
    {
        public string Name;
    }

    class Book
    {
        public string Name;
        public double Price;
    }

}
