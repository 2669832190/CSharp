﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _5.窗体应用尝试
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        //定义一个变量表示点击的次数
        int count = 0;
        private void button1_Click(object sender, EventArgs e)
        {
            count = count + 1;
            //消息弹框
            //MessageBox.Show(count.ToString());
            //label1.Text = "按钮被点击了" + count + "次";
            if(count>=100)
            {
                label1.Text = "功德无量！";
            }
            else
            {
                label1.Text = "按钮被点击了" + count + "次";
            }
        }
    }
}
